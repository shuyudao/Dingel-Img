<?php
//配置文件
$dbserver = 'localhost';
$dbuser = 'root';
$dbpwd = 'root';
$dbname = 'jjimg'; //注意：你的数据库中必须有此数据库  请先创建
?>